#!/bin/sh
g++ -o ../../Export/GettingStarted ../../Source/GettingStarted.cpp ../../Source/SDLStage.cpp -lSDL
../../Export/GettingStarted
